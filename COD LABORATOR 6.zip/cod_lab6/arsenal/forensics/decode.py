#lab 6 - lucrarea A, decoderul
import re,base64,json,hashlib,argparse
from urllib.parse import unquote   #pt url decode

#ghicim ce codare e dupa cum arata sirul
def ghici_strat(s):
    if re.search(r"%[0-9A-Fa-f]{2}",s):   #are %2F, %20 etc -> e url
        return "url"
    if re.fullmatch(r"[0-9a-fA-F]+",s) and len(s)%2==0:   #doar cifre hex si nr par (2 cifre = 1 octet)
        return "hex"
    if re.fullmatch(r"[A-Za-z0-9+/]+={0,2}",s):   #literele din base64, poate are = la sfarsit
        return "base64"
    return "necunoscut"
    #ordinea e importanta!! hex e si el base64 valid deci trebuie verificat inainte

#decodeaza stratul gasit
def desfa(s):
    t=ghici_strat(s)
    try:
        if t=="base64": return t,base64.b64decode(s)
        if t=="hex": return t,bytes.fromhex(s)
        if t=="url": return t,unquote(s).encode()
    except:
        return "necunoscut",s.encode()   #daca crapa decodarea (ex un cuvant normal) nu oprim programul
    return t,s.encode()

#verifica daca e text normal (caractere de la spatiu=32 pana la ~=126)
def citibil(b):
    return len(b)>0 and all(32<=c<127 for c in b)

#decodam in bucla pana iese text, max 8 ori ca sa nu fie bucla infinita
def desfa_tot(val):
    for i in range(8):
        t,b=desfa(val)
        if t=="necunoscut": break
        if citibil(b): return b   #am ajuns la text citibil, gata
        try: val=b.decode()        #altfel incercam inca un strat
        except: return b
    return val.encode()

#xor cu cheie de 1 octet -> sunt doar 256 de chei deci le incercam pe toate
def sparge_xor(fis):
    d=open(fis,"rb").read()   #rb pt ca e fisier binar
    rez=[]
    for k in range(256):
        x=bytes(c^k for c in d)   #^ e xor, il aplicam pe fiecare octet
        if citibil(x):
            rez.append((k,x))
    return rez

#hashul nu se decripteaza, hashuim fiecare parola din lista si comparam
def sparge_hash(fh,fw):
    h=open(fh).readline().strip()
    #dupa lungime stim algoritmul: 32 md5, 40 sha1, 64 sha256
    if len(h)==32: alg="md5"
    elif len(h)==40: alg="sha1"
    elif len(h)==64: alg="sha256"
    else: return None
    for w in open(fw,encoding="latin1"):   #latin1 ca sa nu dea eroare la caractere ciudate
        w=w.strip()
        if hashlib.new(alg,w.encode()).hexdigest()==h:
            return w
    return None

if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("intrare")                       #sirul sau calea spre fisier
    p.add_argument("--fisier",action="store_true")  #daca il punem, intrarea e fisier
    a=p.parse_args()
    if a.fisier: s=open(a.intrare,"rb").read().decode("latin1")
    else: s=a.intrare
    r=desfa_tot(s)
    print("strat:",ghici_strat(s))
    print("rezultat:",r.decode("latin1"))
    #salvam fisa in json
    json.dump({"strat":ghici_strat(s),"rezultat":r.decode("latin1")},open("arsenal/forensics/fisa.json","w"),indent=2)
    print("am salvat fisa.json")
