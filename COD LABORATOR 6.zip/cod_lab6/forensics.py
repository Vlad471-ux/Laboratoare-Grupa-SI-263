#lab 6 - lucrarea B (B1-B6) forensics + stego
import re,zipfile
from PIL import Image
from PIL.ExifTags import GPSTAGS

#B1 - tipul real dupa primii octeti (magic bytes), extensia poate sa minta
def tip_real(f):
    cap=open(f,"rb").read(8)
    if cap[:4]==b"%PDF": return "pdf"
    if cap[:4]==b"\x89PNG": return "png"
    if cap[:2]==b"\xff\xd8": return "jpeg"
    if cap[:4]==b"PK\x03\x04": return "zip/docx"   #docx e tot un zip
    return cap.hex()

print("B1")
print("foto.jpg ->",tip_real("probe/foto.jpg"))
print("ascuns.png ->",tip_real("probe/ascuns.png"))

#B2 - strings: cautam bucati de text citibil de minim 4 caractere in fisierul binar
print("\nB2")
d=open("probe/ascuns.png","rb").read()
for m in re.findall(rb"[ -~]{4,}",d):   #[ -~] = orice caracter de la spatiu pana la ~
    print(m.decode())

#B3 - exif si gps
print("\nB3")
exif=Image.open("probe/foto.jpg")._getexif() or {}
gps={}
for k,v in exif.get(34853,{}).items():   #34853 e codul pt blocul de GPS
    gps[GPSTAGS.get(k,k)]=v              #transformam codul in nume (ex 2 -> GPSLatitude)

#gps vine ca (grade,minute,secunde), il facem grade zecimale
def zecimal(dms,ref):
    g,m,s=[float(x) for x in dms]
    r=g+m/60+s/3600
    if ref in ("S","W"): r=-r   #sud si vest sunt negative
    return r

lat=zecimal(gps["GPSLatitude"],gps["GPSLatitudeRef"])
lon=zecimal(gps["GPSLongitude"],gps["GPSLongitudeRef"])
print("GPS:",lat,lon)

#B4 - file carving, zip-ul e lipit la coada pozei
print("\nB4")
i=d.find(b"PK\x03\x04")   #cautam unde incepe zip-ul
if i!=-1:
    open("gasit.zip","wb").write(d[i:])   #scriem tot de acolo pana la final
    print("arhiva gasita la octetul",i)
    z=zipfile.ZipFile("gasit.zip")
    for n in z.namelist():
        print(n,":",z.read(n).decode())

#B5 - ascundem mesajul in ultimul bit din fiecare culoare (LSB)
print("\nB5")
img=Image.open("probe/foto.jpg").convert("RGB")
px=list(img.getdata())
msg=b"FLAG{ascuns_in_pixeli}"+b"\x00"   #punem un 0 la final ca sa stim unde se termina
biti="".join(f"{x:08b}" for x in msg)    #fiecare octet -> 8 biti
nou=[]
j=0
for p in px:
    p=list(p)
    for c in range(3):   #r g b
        if j<len(biti):
            p[c]=(p[c]&~1)|int(biti[j])   #&~1 sterge ultimul bit, | pune bitul nostru
            j+=1
    nou.append(tuple(p))
img.putdata(nou)
img.save("stego.png")   #NEAPARAT png, jpg strica bitii la compresie
print("am salvat stego.png")

#B6 - citim mesajul inapoi, invers ca la B5
print("\nB6")
px=list(Image.open("stego.png").convert("RGB").getdata())
biti=""
for (r,g,b) in px:
    biti+=str(r&1)+str(g&1)+str(b&1)   #luam ultimul bit din fiecare culoare
out=b""
for k in range(0,len(biti),8):
    o=int(biti[k:k+8],2)   #8 biti -> un numar
    if o==0: break          #am dat de 0, s-a terminat mesajul
    out+=bytes([o])
print("mesaj:",out.decode())
