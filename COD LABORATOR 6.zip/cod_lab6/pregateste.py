#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pregateste.py - genereaza fisierele de laborator in probe/ (versiune de exemplu).
In laborator primesti un pregateste.py de la profesor; secretele lui difera.
Codul tau (decode/forensics/stego) functioneaza la fel pe oricare dintre ele.
"""
import os, base64, zipfile, hashlib
from PIL import Image
import piexif

os.makedirs("probe", exist_ok=True)

# 1) mesaj.txt - un sir codat (base64 care decodeaza la un text citibil)
with open("probe/mesaj.txt", "w") as f:
    f.write(base64.b64encode(b"FLAG: SI-263 date invizibile").decode())

# 2) xor.bin - text criptat cu XOR pe un singur octet (cheia 0x2A = 42)
clar = b"Cheia XOR gasita: felicitari, Russu!"
with open("probe/xor.bin", "wb") as f:
    f.write(bytes(b ^ 0x2A for b in clar))

# 3) hashuri.txt - un md5 de spart; parola "Russu2026" e in wordlist
with open("probe/hashuri.txt", "w") as f:
    f.write(hashlib.md5(b"Russu2026").hexdigest() + "\n")
with open("probe/wordlist.txt", "w") as f:
    f.write("\n".join(["123456", "parola", "admin", "Russu2026", "qwerty"]))

# 4) foto.jpg - poza cu EXIF si GPS (coordonate Chisinau)
img = Image.new("RGB", (64, 64), (120, 160, 200))
def _rat(x):  # grade zecimale -> ((g,1),(m,1),(s,100)) pentru EXIF
    g = int(x); m = int((x - g) * 60); s = round((((x - g) * 60) - m) * 60 * 100)
    return ((g, 1), (m, 1), (s, 100))
gps = {
    piexif.GPSIFD.GPSLatitudeRef: b"N",
    piexif.GPSIFD.GPSLatitude: _rat(47.0105),
    piexif.GPSIFD.GPSLongitudeRef: b"E",
    piexif.GPSIFD.GPSLongitude: _rat(28.8638),
}
exif = {"0th": {piexif.ImageIFD.Make: b"UTM", piexif.ImageIFD.Model: b"Lab6"},
        "GPS": gps, "Exif": {}, "1st": {}, "thumbnail": None}
img.save("probe/foto.jpg", exif=piexif.dump(exif))

# 5) ascuns.png - PNG cu o arhiva ZIP lipita la coada
Image.new("RGB", (32, 32), (10, 10, 10)).save("probe/ascuns.png")
with zipfile.ZipFile("probe/secret.zip", "w") as z:
    z.writestr("secret.txt", "FLAG{fisier_ascuns_la_coada}")
with open("probe/ascuns.png", "ab") as f, open("probe/secret.zip", "rb") as z:
    f.write(z.read())
os.remove("probe/secret.zip")

print("Fisiere generate in probe/:", sorted(os.listdir("probe")))
