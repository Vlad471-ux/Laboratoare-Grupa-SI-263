#testul pt decoder
from arsenal.forensics.decode import desfa

def test_base64():
    t,b=desfa("U2FsdXQ=")   #U2FsdXQ= e "Salut" in base64
    assert t=="base64"
    assert b==b"Salut"
