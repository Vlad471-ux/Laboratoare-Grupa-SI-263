# Laborator: funcții, metode și importuri pe web
# Student: Russu Vladislav, grupa SI-263
#
# main.py - programul care folosește modulul meu webtools.py
# Rulare: python main.py https://cybercor.org

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import argparse
import csv
import time
from datetime import datetime

# Exercițiul 44: import webtools -> funcțiile se apelează cu webtools.nume()
import webtools

# Exercițiul 45: import doar anumite nume -> se apelează direct get_title()
from webtools import get_title, security_headers
# Dacă main.py ar avea și o funcție proprie numită get_title, definită după
# acest import, ea ar înlocui (ar acoperi) numele importat: de la acel rând,
# get_title() ar apela funcția din main.py, nu pe cea din webtools.
# webtools.get_title() ar funcționa în continuare, pentru că are prefixul modulului.

# Exercițiul 47: import constanta de modul
from webtools import DEFAULT_HEADERS


def save_csv(results: dict, filename: str) -> None:
    """Salvează rezultatul lui check_paths() în fișierul CSV filename.

    Coloanele sunt path, status și checked_at (ora verificării).
    """
    with open(filename, "w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["path", "status", "checked_at"])
        for path, status in results.items():
            writer.writerow([path, status, datetime.now().isoformat()])


def main() -> None:
    """Citește URL-ul din linia de comandă și rulează exercițiile 44-50."""
    # Exercițiul 48: argumente din linia de comandă
    parser = argparse.ArgumentParser(description="Raport despre un site web")
    parser.add_argument("url", nargs="?", default=BASE_URL,
                        help="adresa site-ului, de exemplu https://cybercor.org")
    args = parser.parse_args()
    url = args.url  # de aici înainte folosesc url, nu BASE_URL

    # Exercițiul 44
    print("webtools.get_title(webtools.fetch(url).text) ->",
          webtools.get_title(webtools.fetch(url).text))
    time.sleep(1)

    print()
    # Exercițiul 45
    print("get_title(...) ->", get_title(webtools.fetch(url).text))
    time.sleep(1)
    print("security_headers(url) ->", security_headers(url))
    time.sleep(1)

    print()
    # Exercițiul 47
    print("DEFAULT_HEADERS =", DEFAULT_HEADERS)

    print()
    # Exercițiul 48
    print("URL primit din linia de comandă:", url)

    print()
    # Exercițiul 49
    rezultate = webtools.check_paths(url, ["/", "/robots.txt", "/sitemap.xml"])
    save_csv(rezultate, "report.csv")
    print("Salvat în report.csv:")
    with open("report.csv", "r", encoding="utf-8") as file:
        print(file.read().strip())

    print()
    # Exercițiul 50
    webtools.site_report(url)


if __name__ == "__main__":
    main()
