# Laborator: funcții, metode și importuri pe web
# Student: Russu Vladislav, grupa SI-263
#
# webtools.py - modulul meu: toate funcțiile reutilizabile din laborator.
# Se importă din main.py cu "import webtools" sau "from webtools import ...".

import time
import re
import json
import socket
import ssl
from datetime import datetime, timezone
from urllib.parse import urlparse, urljoin

import requests

TIMEOUT = 10  # secunde

# Exercițiul 47: constantă de modul, folosită în fetch()
DEFAULT_HEADERS = {"User-Agent": "WebLab-RussuVladislav"}

SECURITY_HEADERS = [
    "Strict-Transport-Security",
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
]


# ---------- funcții mutate din Partea 3 (exercițiul 44) ----------

def fetch(url: str, timeout: int = TIMEOUT) -> requests.Response:
    """Descarcă adresa url și returnează obiectul răspuns.

    Trimite antetele din DEFAULT_HEADERS (User-Agent-ul meu).
    """
    return requests.get(url, headers=DEFAULT_HEADERS, timeout=timeout)


def get_status(url: str) -> int:
    """Returnează codul de stare HTTP pentru adresa url."""
    return fetch(url).status_code


def get_title(html: str) -> str:
    """Returnează textul dintre <title> și </title> sau "" dacă nu există."""
    pozitie = html.find("<title>")
    if pozitie == -1:
        return ""
    start = pozitie + len("<title>")
    end = html.find("</title>", start)
    return html[start:end].strip()


def security_headers(url: str) -> dict:
    """Returnează {antet: True/False} pentru cele cinci antete de securitate."""
    response = fetch(url)
    rezultat = {}
    for antet in SECURITY_HEADERS:
        rezultat[antet] = antet in response.headers
    return rezultat


# ---------- alte funcții de care are nevoie site_report() ----------

def score_headers(results: dict) -> str:
    """Primește rezultatul lui security_headers() și returnează scorul "x/5"."""
    prezente = 0
    for valoare in results.values():
        if valoare:
            prezente += 1
    return f"{prezente}/{len(results)}"


def check_paths(base: str, paths: list) -> dict:
    """Returnează {cale: cod_de_stare} pentru fiecare cale din paths."""
    rezultat = {}
    for path in paths:
        rezultat[path] = get_status(base.rstrip("/") + path)
        time.sleep(1)
    return rezultat


def fetch_robots(base: str):
    """Returnează textul fișierului /robots.txt sau None dacă lipsește."""
    try:
        response = fetch(base.rstrip("/") + "/robots.txt")
    except requests.RequestException:
        return None
    if response.status_code != 200:
        return None
    return response.text


def disallowed_paths(robots_text) -> list:
    """Returnează valorile din liniile Disallow:, fără repetări (listă goală pentru None)."""
    if robots_text is None:
        return []
    cai = []
    for linie in robots_text.splitlines():
        linie = linie.strip()
        if linie.lower().startswith("disallow:"):
            valoare = linie.split(":", 1)[1].strip()
            if valoare != "" and valoare not in cai:
                cai.append(valoare)
    return cai


def extract_links(html: str) -> list:
    """Returnează toate valorile href="..." din html, fără duplicate."""
    unice = []
    for link in re.findall(r'href="([^"]+)"', html):
        if link not in unice:
            unice.append(link)
    return unice


def split_links(links: list, domain: str):
    """Împarte legăturile în (interne, externe) după domeniu."""
    interne = []
    externe = []
    for link in links:
        complet = urljoin("https://" + domain + "/", link)
        parti = urlparse(complet)
        if parti.scheme not in ("http", "https"):
            continue
        if parti.netloc == domain:
            interne.append(complet)
        else:
            externe.append(complet)
    return interne, externe


def resolve(hostname: str) -> str:
    """Returnează adresa IPv4 a domeniului hostname."""
    return socket.gethostbyname(hostname)


def cert_days_left(hostname: str) -> int:
    """Returnează numărul de zile până la expirarea certificatului TLS."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()
    expira_la = ssl.cert_time_to_seconds(cert["notAfter"])
    data_expirarii = datetime.fromtimestamp(expira_la, tz=timezone.utc)
    return (data_expirarii - datetime.now(timezone.utc)).days


def redirect_chain(url: str):
    """Urmărește redirecționările pornind de la url.

    Returnează (lista de pași "cod -> URL nou", răspunsul final).
    """
    response = fetch(url)
    pasi = []
    for i, pas in enumerate(response.history):
        # URL-ul la care s-a ajuns după acest pas: următorul din istoric
        # sau, pentru ultimul pas, URL-ul final
        if i + 1 < len(response.history):
            urmatorul = response.history[i + 1].url
        else:
            urmatorul = response.url
        pasi.append(f"{pas.status_code} -> {urmatorul}")
    return pasi, response


# ---------- Exercițiul 50: proiectul final ----------

def site_report(url: str) -> dict:
    """Colectează informațiile despre site, le afișează și le salvează în report.json."""
    hostname = urlparse(url).netloc
    raport = {"url": url}

    # 1. codul de stare și URL-ul final
    response = fetch(url)
    raport["status_code"] = response.status_code
    raport["final_url"] = response.url
    time.sleep(1)

    # 2. titlul paginii
    raport["title"] = get_title(response.text)

    # 3. adresa IP
    raport["ip"] = resolve(hostname)

    # 4. lanțul de redirecționări pornind de la http://
    pasi, _ = redirect_chain("http://" + hostname)
    raport["redirects"] = pasi
    time.sleep(1)

    # 5. scorul antetelor de securitate
    raport["security_headers"] = security_headers(url)
    raport["security_score"] = score_headers(raport["security_headers"])
    time.sleep(1)

    # 6. zilele rămase până la expirarea certificatului
    raport["cert_days_left"] = cert_days_left(hostname)

    # 7. numărul de legături interne și externe
    interne, externe = split_links(extract_links(response.text), hostname)
    raport["internal_links"] = len(interne)
    raport["external_links"] = len(externe)

    # 8. căile interzise din robots.txt
    raport["disallowed_paths"] = disallowed_paths(fetch_robots(url))

    raport["generated_at"] = datetime.now().isoformat()

    # pregătesc textele pentru afișare
    if pasi:
        redirectionari = ", ".join(pasi)
    else:
        redirectionari = "niciuna"
    zile = raport["cert_days_left"]
    # în română: 1-19 zile, dar 20 de zile, 74 de zile
    if zile % 100 >= 20 or (zile >= 100 and zile % 100 == 0):
        certificat = f"{zile} de zile rămase"
    else:
        certificat = f"{zile} zile rămase"
    if raport["disallowed_paths"]:
        interzise = ", ".join(raport["disallowed_paths"])
    else:
        interzise = "niciuna"

    # afișarea raportului; {:<19} aliniază valorile pe aceeași coloană
    print(f"=== Raport site: {url} ===")
    print(f"{'Cod de stare:':<19}{raport['status_code']}")
    print(f"{'URL final:':<19}{raport['final_url']}")
    print(f"{'Titlu:':<19}{raport['title']}")
    print(f"{'Adresă IP:':<19}{raport['ip']}")
    print(f"{'Redirecționări:':<19}{redirectionari}")
    print(f"{'Scor securitate:':<19}{raport['security_score']}")
    print(f"{'Certificat:':<19}{certificat}")
    print(f"{'Legături:':<19}{raport['internal_links']} interne, {raport['external_links']} externe")
    print(f"{'Căi interzise:':<19}{interzise}")

    # salvarea în report.json
    with open("report.json", "w", encoding="utf-8") as file:
        json.dump(raport, file, indent=2, ensure_ascii=False)
    print("Salvat în report.json")
    return raport


# Exercițiul 46: blocul main - autotestul rulează doar la "python webtools.py"
if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))
