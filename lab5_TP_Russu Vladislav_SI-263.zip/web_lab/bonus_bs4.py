# Laborator: funcții, metode și importuri pe web
# Student: Russu Vladislav, grupa SI-263
#
# Bonus: get_title() și extract_links() rescrise cu BeautifulSoup
# Instalare: pip install beautifulsoup4

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

from bs4 import BeautifulSoup

import webtools  # versiunile mele vechi, pentru comparație


def get_title_bs4(html: str) -> str:
    """Returnează titlul paginii folosind BeautifulSoup."""
    soup = BeautifulSoup(html, "html.parser")
    if soup.title is None or soup.title.string is None:
        return ""
    return soup.title.string.strip()


def extract_links_bs4(html: str) -> list:
    """Returnează valorile atributului href din toate tag-urile, fără duplicate."""
    soup = BeautifulSoup(html, "html.parser")
    links = [tag["href"] for tag in soup.find_all(href=True)]
    return list(dict.fromkeys(links))  # dict.fromkeys păstrează ordinea și scoate duplicatele


html = webtools.fetch(BASE_URL).text

print("===== Bonus: BeautifulSoup =====")
print("Titlu cu find() + slicing:", webtools.get_title(html))
print("Titlu cu BeautifulSoup:   ", get_title_bs4(html))

links_re = webtools.extract_links(html)
links_bs4 = extract_links_bs4(html)
print("Legături cu re.findall():  ", len(links_re))
print("Legături cu BeautifulSoup: ", len(links_bs4))
print("Doar la BeautifulSoup:", [l for l in links_bs4 if l not in links_re])
print("Doar la re.findall():", [l for l in links_re if l not in links_bs4])

# Test pe HTML "greu", unde metodele simple greșesc:
test = """<html><head><TITLE lang="ro">  Pagina de test  </TITLE></head>
<body><a href='/cu-apostrof'>1</a> <a href=/fara-ghilimele>2</a>
<!-- <a href="/in-comentariu">3</a> --></body></html>"""
print("\nTest pe HTML scris de mine:")
print("find() + slicing:", repr(webtools.get_title(test)))
print("BeautifulSoup:   ", repr(get_title_bs4(test)))
print("re.findall():    ", webtools.extract_links(test))
print("BeautifulSoup:   ", extract_links_bs4(test))

# Concluzie: cu BeautifulSoup funcțiile au 2-3 linii, iar codul este mai sigur:
# găsește <TITLE> scris cu majuscule sau cu atribute, href-uri cu apostrof
# sau fără ghilimele și ignoră legăturile din comentariile HTML.
# Variantele mele cu find() și expresii regulate nu găsesc aceste cazuri.
