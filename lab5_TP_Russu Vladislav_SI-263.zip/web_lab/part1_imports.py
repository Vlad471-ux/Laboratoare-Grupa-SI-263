# Laborator: funcții, metode și importuri pe web
# Student: Russu Vladislav, grupa SI-263

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# Partea 1: Importuri (exercițiile 1-8)

import time  # pentru time.sleep(1) între cereri și pentru cronometrare (ex. 7)


# ---------------- Exercițiul 1. Primul import ----------------
print("===== Exercițiul 1 =====")

import requests
print("Versiunea bibliotecii requests:", requests.__version__)

import urllib.request
print("Modulul urllib.request a fost importat:", urllib.request.__name__)

# requests a avut nevoie de "pip install requests" pentru că este o bibliotecă
# externă (third-party). Ea nu vine împreună cu Python, trebuie descărcată
# din PyPI (Python Package Index) cu pip.
# urllib face parte din biblioteca standard a lui Python. Se instalează
# automat odată cu interpretorul, de aceea poate fi importat direct.


# ---------------- Exercițiul 2. Două stiluri de import ----------------
print("\n===== Exercițiul 2 =====")

# Stilul 1: import requests -> scriu numele modulului în fața funcției
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("requests.get() -> cod de stare:", response.status_code)
time.sleep(1)

# Stilul 2: from requests import get -> folosesc direct get()
from requests import get
response = get(BASE_URL, timeout=TIMEOUT)
print("get() -> cod de stare:", response.status_code)
time.sleep(1)

# Avantaj "import requests": se vede clar de unde vine funcția (requests.get),
# iar numele get nu se poate amesteca cu o altă funcție get din program.
# Avantaj "from requests import get": codul este mai scurt, scriu doar get(...).


# ---------------- Exercițiul 3. Alias-uri ----------------
print("\n===== Exercițiul 3 =====")

import requests as rq
response = rq.get(BASE_URL, timeout=TIMEOUT)
print("rq.get() -> cod de stare:", response.status_code)
time.sleep(1)

# Un alias face codul mai ușor de citit când numele modulului este lung și
# alias-ul este o convenție cunoscută de toți (import numpy as np,
# import pandas as pd).
# Îl face mai greu de citit când alias-ul este inventat și nu spune nimic
# (de exemplu rq): cine citește codul trebuie să caute la început ce este rq.


# ---------------- Exercițiul 4. Doar biblioteca standard ----------------
print("\n===== Exercițiul 4 =====")

import urllib.error

try:
    with urllib.request.urlopen(BASE_URL, timeout=TIMEOUT) as raspuns:
        print("Status (.status):", raspuns.status)
        corp = raspuns.read().decode("utf-8")  # read() dă bytes, decode() îi face str
    print("Primele 200 de caractere din corp:")
    print(corp[:200])
except urllib.error.HTTPError as e:
    print("urlopen(BASE_URL) -> serverul a răspuns cu eroarea", e.code)
time.sleep(1)

# La prima rulare am primit 403 (Forbidden). Site-ul este protejat de Cloudflare
# (antetul Server: cloudflare), care blochează User-Agent-ul implicit al lui
# urllib ("Python-urllib/3.x"). Trimit aceeași cerere, tot doar cu urllib,
# dar cu un User-Agent propriu, pus într-un obiect Request:
cerere = urllib.request.Request(BASE_URL, headers={"User-Agent": "WebLab-RussuVladislav"})
try:
    with urllib.request.urlopen(cerere, timeout=TIMEOUT) as raspuns:
        print("Cu User-Agent propriu -> status (.status):", raspuns.status)
        corp = raspuns.read().decode("utf-8")
    print("Primele 200 de caractere din corp:")
    print(corp[:200])
except urllib.error.HTTPError as e:
    print("Și cu User-Agent propriu serverul a răspuns cu eroarea", e.code)
time.sleep(1)


# ---------------- Exercițiul 5. Priviți în interiorul unui modul ----------------
print("\n===== Exercițiul 5 =====")

print(dir(requests))

# Am ales trei nume din listă:
# get        -> funcție (trimite o cerere GET)
# Session    -> clasă (din ea se creează obiecte sesiune)
# exceptions -> modul (requests/exceptions.py, conține clasele de erori)
print("get:", type(requests.get))
print("Session:", type(requests.Session))
print("exceptions:", type(requests.exceptions))


# ---------------- Exercițiul 6. Citiți documentația ----------------
print("\n===== Exercițiul 6 =====")

help(requests.get)

# În help(requests.get) se vede că get() primește **kwargs și îi trimite mai
# departe funcției requests.request(). Acolo este descris parametrul timeout:
for linie in requests.request.__doc__.splitlines():
    if "timeout" in linie:
        print(linie.strip())

# Parametrul care setează timpul maxim de așteptare este timeout.
response = requests.get(BASE_URL, timeout=5)
print("Cerere cu timeout=5 -> cod de stare:", response.status_code)
time.sleep(1)


# ---------------- Exercițiul 7. Cronometrarea unei cereri ----------------
print("\n===== Exercițiul 7 =====")

start = time.perf_counter()
response = requests.get(BASE_URL, timeout=TIMEOUT)
stop = time.perf_counter()

print("Timp măsurat cu time.perf_counter():", round(stop - start, 3), "secunde")
print("Timp din response.elapsed:", response.elapsed.total_seconds(), "secunde")
time.sleep(1)

# perf_counter() măsoară tot: deschiderea conexiunii, trimiterea cererii,
# descărcarea întregului corp și crearea obiectului Response.
# response.elapsed măsoară doar timpul de la trimiterea cererii până când
# au sosit antetele răspunsului. De aceea perf_counter() dă un timp mai mare.


# ---------------- Exercițiul 8. Când un import eșuează ----------------
print("\n===== Exercițiul 8 =====")

try:
    import bs4
    print("Modulul bs4 este instalat, versiunea", bs4.__version__)
except ImportError:
    print("Instalați modulul cu: pip install beautifulsoup4")


# Verificați-vă: modul, pachet, bibliotecă
# Modul = un singur fișier .py (de exemplu time sau un fișier scris de mine).
# Pachet = un director cu mai multe module (are __init__.py), de exemplu
#          requests sau urllib (urllib.request, urllib.parse sunt module din el).
# Bibliotecă = un termen mai general: o colecție de cod gata scris, formată din
#          unul sau mai multe pachete/module (biblioteca standard, requests).
