# Laborator: funcții, metode și importuri pe web
# Student: Russu Vladislav, grupa SI-263

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# Partea 2: Metode și atribute ale obiectelor web (exercițiile 9-20)

import time
import requests


# ---------------- Exercițiul 9. Elementele de bază ale răspunsului ----------------
print("===== Exercițiul 9 =====")

response = requests.get(BASE_URL, timeout=TIMEOUT)
print("status_code:", response.status_code)  # atribut
print("ok:", response.ok)                    # atribut (proprietate, fără paranteze)
print("url:", response.url)                  # atribut
print("encoding:", response.encoding)        # atribut
time.sleep(1)


# ---------------- Exercițiul 10. Tratarea erorilor cu o metodă ----------------
print("\n===== Exercițiul 10 =====")

response.raise_for_status()  # metodă: pentru 200 nu face nimic
print("Pagina principală: raise_for_status() nu a ridicat nicio eroare")

try:
    r = requests.get(BASE_URL + "/this-page-does-not-exist", timeout=TIMEOUT)
    r.raise_for_status()  # pentru 4xx/5xx ridică requests.HTTPError
except requests.HTTPError as e:
    print(f"Pagina {e.response.url} nu există (cod {e.response.status_code}).")
    print("Eroarea a fost prinsă, programul continuă.")
else:
    print("Pagina a răspuns cu codul", r.status_code)
    print("Conținutul este identic cu pagina principală:", r.text == response.text)
time.sleep(1)

# Site-ul răspunde cu 200 și la adrese care nu există: serverul (Express, se
# vede în antetul X-Powered-By) trimite aceeași pagină index.html pentru orice
# cale, iar conținutul îl construiește JavaScript-ul în browser (aplicație SPA).
# De aceea excepția nu a apărut. Ca să verific și ramura except, trimit o
# cerere la httpbin, care returnează intenționat codul scris în adresă:
try:
    r = requests.get(ECHO_URL + "/status/404", timeout=TIMEOUT)
    r.raise_for_status()
except requests.HTTPError as e:
    print(f"Pagina {e.response.url} nu există (cod {e.response.status_code}).")
    print("Eroarea a fost prinsă, programul continuă.")
time.sleep(1)


# ---------------- Exercițiul 11. Toate antetele ----------------
print("\n===== Exercițiul 11 =====")

for nume, valoare in response.headers.items():
    print(f"{nume}: {valoare}")


# ---------------- Exercițiul 12. Metode de dicționar ----------------
print("\n===== Exercițiul 12 =====")

print("Server:", response.headers.get("Server", "lipsește"))
print("Content-Type:", response.headers.get("Content-Type", "lipsește"))
print("content-type (litere mici):", response.headers.get("content-type", "lipsește"))

# Observație: și cu litere mici primesc aceeași valoare. response.headers nu
# este un dict obișnuit, ci un CaseInsensitiveDict, pentru că numele
# antetelor HTTP nu țin cont de majuscule.
print("Tipul lui response.headers:", type(response.headers).__name__)


# ---------------- Exercițiul 13. Înlănțuirea metodelor de șir ----------------
print("\n===== Exercițiul 13 =====")

numar = response.text.lower().count("cyber")
print("Cuvântul 'cyber' apare de", numar, "ori pe pagina principală")

# Pot înlănțui .lower() și .count() deoarece .lower() returnează un șir nou
# (str), iar pe acest șir nou pot apela imediat altă metodă a lui str, .count().
# Metodele se execută de la stânga la dreapta.


# ---------------- Exercițiul 14. Găsirea titlului ----------------
print("\n===== Exercițiul 14 =====")

html = response.text
start = html.find("<title>") + len("<title>")
end = html.find("</title>", start)
titlu = html[start:end].strip()
print("Titlul paginii:", titlu)


# ---------------- Exercițiul 15. Numărarea liniilor ----------------
print("\n===== Exercițiul 15 =====")

lines = html.splitlines()
print("Numărul de linii din HTML:", len(lines))
print("Lungimea celei mai lungi linii:", len(max(lines, key=len)), "caractere")


# ---------------- Exercițiul 16. Verificarea HTTPS ----------------
print("\n===== Exercițiul 16 =====")

if response.url.startswith("https://"):
    print("Conexiune securizată")
else:
    print("Conexiune nesecurizată")


# ---------------- Exercițiul 17. Urmărirea redirecționărilor ----------------
print("\n===== Exercițiul 17 =====")

r = requests.get("http://cybercor.org", timeout=TIMEOUT)
if len(r.history) == 0:
    print("Nu a fost nicio redirecționare")
for pas in r.history:
    print("Redirecționare:", pas.status_code, pas.url)
print("URL final:", r.status_code, r.url)
time.sleep(1)


# ---------------- Exercițiul 18. HEAD versus GET ----------------
print("\n===== Exercițiul 18 =====")

r_head = requests.head(BASE_URL, timeout=TIMEOUT)
time.sleep(1)
r_get = requests.get(BASE_URL, timeout=TIMEOUT)
time.sleep(1)
print("HEAD -> cod", r_head.status_code, "| len(content) =", len(r_head.content))
print("GET  -> cod", r_get.status_code, "| len(content) =", len(r_get.content))

# HEAD cere doar antetele, serverul nu trimite corpul, de aceea content este
# gol (0 octeți). GET primește și antetele, și corpul (tot codul HTML).
# HEAD este util când vreau doar să verific dacă pagina există sau ce antete are.


# ---------------- Exercițiul 19. Cookie-uri ----------------
print("\n===== Exercițiul 19 =====")

if len(response.cookies) == 0:
    print("Niciun cookie setat")
for cookie in response.cookies:
    print("Cookie:", cookie.name, "| secure:", cookie.secure)


# ---------------- Exercițiul 20. Sesiuni ----------------
print("\n===== Exercițiul 20 =====")

session = requests.Session()
session.headers.update({"User-Agent": "WebLab-RussuVladislav"})
r = session.get(ECHO_URL + "/headers", timeout=TIMEOUT)
date = r.json()
print("Antetele văzute de httpbin:")
for nume, valoare in date["headers"].items():
    print(f"  {nume}: {valoare}")
print("User-Agent trimis:", date["headers"]["User-Agent"])
if date["headers"]["User-Agent"] == "WebLab-RussuVladislav":
    print("Confirmat: antetul personalizat a fost trimis.")
session.close()


# Verificați-vă: response.text și response.json()
# response.text este o proprietate (atribut): doar decodează corpul în str,
# de aceea se scrie fără paranteze.
# response.json() este o metodă: face o acțiune, analizează (parsează) textul
# ca JSON, poate primi argumente și poate ridica o eroare dacă textul nu este
# JSON valid. De aceea se apelează cu paranteze.
