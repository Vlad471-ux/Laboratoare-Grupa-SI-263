# Laborator: funcții, metode și importuri pe web
# Student: Russu Vladislav, grupa SI-263

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# Partea 4: Alte module din biblioteca standard (exercițiile 35-43)

import time
import re
import json
import socket
import ssl
import hashlib
from datetime import datetime, timezone
from urllib.parse import urlparse, urljoin
from html.parser import HTMLParser

import requests


# ---------------- Exercițiul 35. Descompunerea unui URL ----------------
print("===== Exercițiul 35 =====")

def show_url_parts(url: str) -> None:
    """Descompune url cu urlparse() și afișează fiecare parte."""
    parti = urlparse(url)
    print("scheme:  ", parti.scheme)
    print("netloc:  ", parti.netloc)
    print("path:    ", parti.path)
    print("query:   ", parti.query)
    print("fragment:", parti.fragment)

show_url_parts("https://cybercor.org/path?x=1#top")


# ---------------- Exercițiul 36. Compunerea URL-urilor ----------------
print("\n===== Exercițiul 36 =====")

def make_absolute(base: str, links: list) -> list:
    """Transformă legăturile relative din links în URL-uri complete."""
    rezultat = []
    for link in links:
        rezultat.append(urljoin(base, link))
    return rezultat

relative = ["/about", "contact.html", "../index.html"]
for relativ, complet in zip(relative, make_absolute(BASE_URL, relative)):
    print(relativ, "->", complet)


# ---------------- Exercițiul 37. Extragerea legăturilor ----------------
print("\n===== Exercițiul 37 =====")

def extract_links(html: str) -> list:
    """Returnează toate valorile href="..." din html, fără duplicate.

    Ordinea în care apar în pagină se păstrează.
    """
    toate = re.findall(r'href="([^"]+)"', html)
    unice = []
    for link in toate:
        if link not in unice:
            unice.append(link)
    return unice

response = requests.get(BASE_URL, timeout=TIMEOUT)
html = response.text
links = extract_links(html)
print("Legături găsite (fără duplicate):", len(links))
for link in links:
    print("  ", link)
time.sleep(1)


# ---------------- Exercițiul 38. Interne sau externe? ----------------
print("\n===== Exercițiul 38 =====")

def split_links(links: list, domain: str):
    """Împarte legăturile în interne (același domeniu) și externe.

    Fiecare legătură este făcută completă cu urljoin(), apoi se compară
    urlparse().netloc cu domeniul. Legăturile mailto:, tel:, javascript:
    nu sunt pagini web și nu sunt numărate.
    Returnează două liste: (interne, externe).
    """
    interne = []
    externe = []
    for link in links:
        complet = urljoin("https://" + domain + "/", link)
        parti = urlparse(complet)
        if parti.scheme not in ("http", "https"):
            continue
        if parti.netloc == domain:
            interne.append(complet)
        else:
            externe.append(complet)
    return interne, externe

interne, externe = split_links(links, "cybercor.org")
print("Interne:", len(interne))
for link in interne:
    print("  ", link)
print("Externe:", len(externe))
for link in externe:
    print("  ", link)


# ---------------- Exercițiul 39. Propriile metode ----------------
print("\n===== Exercițiul 39 =====")

class ImageFinder(HTMLParser):
    """Parser HTML care colectează atributul src al fiecărui tag <img>."""

    def __init__(self):
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        """Este apelată de feed() pentru fiecare tag de deschidere găsit."""
        if tag == "img":                 # HTMLParser dă numele tag-ului cu litere mici
            src = dict(attrs).get("src")  # None dacă tag-ul nu are src
            if src:
                self.images.append(src)

# testul cu HTML cunoscut
test_html = """
<html><body>
<img src="/logo.png" alt="Logo">
<IMG SRC="poza.jpg">
<img alt="imagine fără src">
<img src="https://cdn.example.com/banner.webp" />
<a href="/despre">Aceasta nu este o imagine</a>
</body></html>
"""

finder = ImageFinder()
finder.feed(test_html)
print(finder.images)
assert finder.images == [
    "/logo.png",                            # imagine obișnuită
    "poza.jpg",                             # tag scris cu majuscule
    "https://cdn.example.com/banner.webp",  # tag care se închide singur
], "Parserul nu a găsit exact imaginile așteptate"
print("Testul a trecut!")

# parserul pe pagina reală
response = requests.get(BASE_URL, timeout=TIMEOUT)
finder = ImageFinder()
finder.feed(response.text)
print(len(finder.images), "imagini găsite")
for src in finder.images:
    print(src)
print('Verificare cu response.text.lower().count("<img"):', response.text.lower().count("<img"))
time.sleep(1)


# ---------------- Exercițiul 40. Amprenta paginii ----------------
print("\n===== Exercițiul 40 =====")

def page_fingerprint(url: str) -> str:
    """Returnează amprenta SHA-256 (hex) a conținutului paginii url."""
    response = requests.get(url, timeout=TIMEOUT)
    return hashlib.sha256(response.content).hexdigest()

amprenta1 = page_fingerprint(BASE_URL)
time.sleep(1)
amprenta2 = page_fingerprint(BASE_URL)
time.sleep(1)
print("Prima rulare: ", amprenta1)
print("A doua rulare:", amprenta2)
if amprenta1 == amprenta2:
    print("Amprentele sunt identice: pagina nu s-a schimbat între cereri.")
else:
    print("Amprentele sunt diferite: pagina s-a schimbat între cereri.")

# Amprentele ar fi diferite dacă se schimbă chiar și un singur octet din pagină:
# autorul modifică pagina, pagina conține data/ora curentă, un token sau un
# număr aleator generat la fiecare cerere (de exemplu nonce în CSP), reclame
# sau conținut diferit pentru fiecare vizitator.


# ---------------- Exercițiul 41. Salvarea în JSON ----------------
print("\n===== Exercițiul 41 =====")

def save_headers(url: str, filename: str) -> None:
    """Salvează antetele răspunsului pentru url în fișierul JSON filename."""
    response = requests.get(url, timeout=TIMEOUT)
    with open(filename, "w", encoding="utf-8") as file:
        json.dump(dict(response.headers), file, indent=2)

def load_json(filename: str) -> dict:
    """Încarcă și returnează conținutul fișierului JSON filename."""
    with open(filename, "r", encoding="utf-8") as file:
        return json.load(file)

save_headers(BASE_URL, "headers.json")
print("Antetele au fost salvate în headers.json")
date = load_json("headers.json")
print("Am încărcat", len(date), "antete din fișier")
print("Content-Type din headers.json:", date.get("Content-Type", "lipsește"))
time.sleep(1)


# ---------------- Exercițiul 42. Interogare DNS ----------------
print("\n===== Exercițiul 42 =====")

def resolve(hostname: str) -> str:
    """Returnează adresa IPv4 a domeniului hostname (interogare DNS)."""
    return socket.gethostbyname(hostname)

print("Adresa IP a cybercor.org:", resolve("cybercor.org"))


# ---------------- Exercițiul 43. Expirarea certificatului ----------------
print("\n===== Exercițiul 43 =====")

def cert_days_left(hostname: str) -> int:
    """Returnează câte zile mai sunt până la expirarea certificatului TLS."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()
    expira_la = ssl.cert_time_to_seconds(cert["notAfter"])  # secunde de la 1970
    data_expirarii = datetime.fromtimestamp(expira_la, tz=timezone.utc)
    print("Certificatul expiră la:", cert["notAfter"])
    ramas = data_expirarii - datetime.now(timezone.utc)
    return ramas.days

print("Zile rămase până la expirarea certificatului:", cert_days_left("cybercor.org"))


# Verificați-vă: cine apelează handle_starttag()?
# Nu o apelez eu. O apelează metoda feed() a clasei HTMLParser: feed() citește
# textul HTML și, de fiecare dată când găsește un tag de deschidere, apelează
# self.handle_starttag(tag, attrs). Pentru că am suprascris metoda în clasa
# ImageFinder, se execută versiunea mea.
