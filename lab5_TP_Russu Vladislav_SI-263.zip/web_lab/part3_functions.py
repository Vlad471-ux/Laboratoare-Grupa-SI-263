# Laborator: funcții, metode și importuri pe web
# Student: Russu Vladislav, grupa SI-263

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# Partea 3: Scrierea propriilor funcții (exercițiile 21-34)

import time
import requests


# ---------------- Exercițiul 21. Prima funcție ----------------
print("===== Exercițiul 21 =====")

def fetch(url):
    """Descarcă adresa url și returnează obiectul răspuns (Response)."""
    response = requests.get(url, timeout=TIMEOUT)
    return response

raspuns = fetch(BASE_URL)
print("fetch(BASE_URL) -> cod de stare:", raspuns.status_code)
time.sleep(1)


# ---------------- Exercițiul 22. Returnarea unei singure valori ----------------
print("\n===== Exercițiul 22 =====")

def get_status(url):
    """Returnează codul de stare HTTP pentru adresa url."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code

for cale in ["/", "/robots.txt", "/sitemap.xml"]:
    print(cale, "->", get_status(BASE_URL + cale))
    time.sleep(1)


# ---------------- Exercițiul 23. Parametri impliciți ----------------
print("\n===== Exercițiul 23 =====")

def fetch(url, timeout=10):
    """Descarcă adresa url și returnează răspunsul.

    timeout are valoarea implicită 10 secunde, dar poate fi schimbat la apel.
    """
    response = requests.get(url, timeout=timeout)
    return response

r1 = fetch(BASE_URL)               # se folosește timeout=10 (implicit)
print("fetch(BASE_URL) -> cod", r1.status_code)
time.sleep(1)
r2 = fetch(BASE_URL, timeout=3)    # timeout schimbat la 3 secunde
print("fetch(BASE_URL, timeout=3) -> cod", r2.status_code)
time.sleep(1)


# ---------------- Exercițiul 24. O singură sarcină pe funcție ----------------
print("\n===== Exercițiul 24 =====")

def get_title(html):
    """Primește codul HTML al unei pagini (str) și returnează titlul ei.

    Caută textul dintre <title> și </title>. Dacă pagina nu are titlu,
    returnează un șir gol. Funcția nu face nicio cerere în rețea.
    """
    pozitie = html.find("<title>")
    if pozitie == -1:
        return ""
    start = pozitie + len("<title>")
    end = html.find("</title>", start)
    return html[start:end].strip()

# descărcarea se face separat, get_title doar analizează textul
print("Titlu:", get_title(r1.text))
print("Titlu dintr-un HTML scris de mine:", get_title("<html><title> Test </title></html>"))


# ---------------- Exercițiul 25. Docstring-uri ----------------
print("\n===== Exercițiul 25 =====")

help(get_title)


# ---------------- Exercițiul 26. Adnotări de tip ----------------
print("\n===== Exercițiul 26 =====")

def get_status(url: str) -> int:
    """Returnează codul de stare HTTP pentru adresa url (cu adnotări de tip)."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code

print("Adnotările funcției:", get_status.__annotations__)
try:
    print(get_status(123))
except Exception as e:
    print("Python a pornit apelul get_status(123), eroarea vine din requests:")
    print(type(e).__name__, "-", e)

# Adnotările de tip NU opresc apelul. Python nu verifică tipurile la rulare,
# ele sunt doar informații pentru programator și pentru editor (sau mypy).
# Eroarea de mai sus apare abia în interiorul requests, pentru că "123" nu
# este un URL valid (nu are schemă http:// sau https://).


# ---------------- Exercițiul 27. Fără opriri neașteptate ----------------
print("\n===== Exercițiul 27 =====")

def page_exists(url: str) -> bool:
    """Returnează True dacă pagina răspunde cu un cod de succes, altfel False.

    Orice eroare de rețea (domeniu inexistent, timeout etc.) este prinsă,
    iar funcția returnează False în loc să oprească programul.
    """
    try:
        response = requests.get(url, timeout=TIMEOUT)
        return response.ok
    except requests.RequestException:
        return False

for adresa in [BASE_URL,
               BASE_URL + "/this-page-does-not-exist",
               "https://this-domain-does-not-exist.invalid"]:
    print(adresa, "->", page_exists(adresa))
    time.sleep(1)

# Pagina inexistentă dă True, pentru că site-ul răspunde cu 200 la orice adresă
# (vezi exercițiul 10). Domeniul .invalid nu există deloc, requests ridică
# ConnectionError, funcția o prinde și returnează False.


# ---------------- Exercițiul 28. Returnarea unui dicționar ----------------
print("\n===== Exercițiul 28 =====")

def check_paths(base: str, paths: list) -> dict:
    """Verifică fiecare cale din paths și returnează {cale: cod_de_stare}."""
    rezultat = {}
    for path in paths:
        rezultat[path] = get_status(base + path)
        time.sleep(1)
    return rezultat

print(check_paths(BASE_URL, ["/", "/robots.txt", "/sitemap.xml"]))


# ---------------- Exercițiul 29. Argumente cu nume ----------------
print("\n===== Exercițiul 29 =====")

def get_header(url: str, name: str, default: str = "lipsește") -> str:
    """Returnează valoarea antetului name din răspunsul pentru url.

    Dacă antetul nu există, returnează default.
    """
    response = requests.get(url, timeout=TIMEOUT)
    return response.headers.get(name, default)

print("Server:", get_header(BASE_URL, name="Server"))
time.sleep(1)
print("X-Antet-Inventat:", get_header(BASE_URL, name="X-Antet-Inventat"))
time.sleep(1)


# ---------------- Exercițiul 30. Antete de securitate ----------------
print("\n===== Exercițiul 30 =====")

SECURITY_HEADERS = [
    "Strict-Transport-Security",
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
]

def security_headers(url: str) -> dict:
    """Verifică dacă cele cinci antete de securitate sunt prezente.

    Returnează un dicționar {nume_antet: True/False}.
    """
    response = requests.get(url, timeout=TIMEOUT)
    rezultat = {}
    for antet in SECURITY_HEADERS:
        rezultat[antet] = antet in response.headers
    return rezultat

rezultate = security_headers(BASE_URL)
for antet, prezent in rezultate.items():
    print(antet, "->", prezent)
time.sleep(1)


# ---------------- Exercițiul 31. Funcții care apelează funcții ----------------
print("\n===== Exercițiul 31 =====")

def score_headers(results: dict) -> str:
    """Primește dicționarul de la security_headers() și returnează scorul "x/5"."""
    prezente = 0
    for valoare in results.values():
        if valoare:
            prezente += 1
    return f"{prezente}/{len(results)}"

print("Scor securitate:", score_headers(security_headers(BASE_URL)))
time.sleep(1)


# ---------------- Exercițiul 32. Două funcții, o sarcină ----------------
print("\n===== Exercițiul 32 =====")

def fetch_robots(base: str):
    """Returnează textul fișierului /robots.txt sau None dacă fișierul lipsește."""
    try:
        response = requests.get(base + "/robots.txt", timeout=TIMEOUT)
    except requests.RequestException:
        return None
    if response.status_code != 200:
        return None
    return response.text

def disallowed_paths(robots_text) -> list:
    """Returnează lista cu toate valorile din liniile Disallow: din robots.txt.

    Fiecare valoare apare o singură dată. Dacă primește None (robots.txt
    lipsește), returnează o listă goală.
    """
    if robots_text is None:
        return []
    cai = []
    for linie in robots_text.splitlines():
        linie = linie.strip()
        if linie.lower().startswith("disallow:"):
            valoare = linie.split(":", 1)[1].strip()
            # "Disallow:" gol înseamnă că nu se interzice nimic
            if valoare != "" and valoare not in cai:
                cai.append(valoare)
    return cai

robots = fetch_robots(BASE_URL)
linii = robots.splitlines() if robots is not None else []
print("robots.txt descărcat:", len(linii), "linii")
numar_disallow = 0
for linie in linii:
    if linie.strip().lower().startswith("disallow:"):
        numar_disallow += 1
print("Linii Disallow în fișier:", numar_disallow)
print("Căi interzise (fără repetări):", disallowed_paths(robots))
print("Test cu None:", disallowed_paths(None))
time.sleep(1)


# ---------------- Exercițiul 33. Oricâte argumente ----------------
print("\n===== Exercițiul 33 =====")

def response_times(*urls) -> dict:
    """Primește oricâte URL-uri și returnează {url: secunde} pentru fiecare."""
    timpi = {}
    for url in urls:  # urls este un tuplu cu toate argumentele
        start = time.perf_counter()
        requests.get(url, timeout=TIMEOUT)
        timpi[url] = round(time.perf_counter() - start, 3)
        time.sleep(1)
    return timpi

print(response_times(BASE_URL, BASE_URL + "/robots.txt"))


# ---------------- Exercițiul 34. Argumente cu nume colectate ----------------
print("\n===== Exercițiul 34 =====")

def log(message, **details):
    """Afișează mesajul urmat de fiecare detaliu, în forma cheie=valoare."""
    parti = [message]
    for cheie, valoare in details.items():  # details este un dicționar
        parti.append(f"{cheie}={valoare}")
    print(" | ".join(parti))

log("verificat", url=BASE_URL, status=200)
log("robots.txt", url=BASE_URL + "/robots.txt", status=get_status(BASE_URL + "/robots.txt"))


# Verificați-vă: print() vs return
# print() doar afișează valoarea pe ecran, iar funcția returnează None, deci
# valoarea nu mai poate fi folosită mai departe în program.
# return trimite valoarea înapoi celui care a apelat funcția. Ea poate fi
# salvată într-o variabilă, trimisă altei funcții (ca la score_headers) sau
# scrisă într-un fișier.
